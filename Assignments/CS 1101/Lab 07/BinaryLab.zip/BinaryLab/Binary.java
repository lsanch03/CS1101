public class Binary {
  public static void printAllBinaryStrings(int x) {
    recurBinaryStrings(x, "");
  }

  private static void recurBinaryStrings(int x, String s) {

  }
}